﻿# HitokotoComponent
Made by 星标 with Kimi.ai （
ヾ(•ω•\`)o`)