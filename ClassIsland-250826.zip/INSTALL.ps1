# 定义下载地址和本地临时文件路径
$Url = "https://ghproxy.net/https://github.com/ClassIsland/ClassIsland/releases/download/1.7.105.0/ClassIsland_app_windows_x64_full_folder.zip"
$ZipFile = "$PSScriptRoot\ClassIsland_app_windows_x64_full_folder.zip"

Write-Host "正在下载文件..." -ForegroundColor Cyan
Invoke-WebRequest -Uri $Url -OutFile $ZipFile

Write-Host "正在解压文件..." -ForegroundColor Cyan
# 解压到当前目录，覆盖已存在文件
Expand-Archive -Path $ZipFile -DestinationPath $PSScriptRoot -Force

Write-Host "清理临时文件..." -ForegroundColor Cyan
Remove-Item $ZipFile -Force

Write-Host "完成！" -ForegroundColor Green
