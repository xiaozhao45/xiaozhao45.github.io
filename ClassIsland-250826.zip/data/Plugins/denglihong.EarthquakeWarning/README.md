![Banner](https://raw.githubusercontent.com/denglihong2007/MyPhotoBed/refs/heads/master/e695f20f-2474-41ce-be05-4957873ee48b.png)
![Banner](https://raw.githubusercontent.com/denglihong2007/MyPhotoBed/refs/heads/master/a22e6600-8252-4f6c-9809-ea00c366c4ce.png)

# 地震预警

一个为ClassIsLand提供地震预警功能的插件。

**注意事项：**

- 您理解地震预警信息由“成都高新减灾研究所”提供，插件作者不对其拥有任何控制权。插件作者对其预警信息的准确性、有效性、及时性均不作承诺和保证，亦不保证地震预警服务能够满足您的所有需求。
- 本项目部分代码参考了kengwang的EarthQuakeWarning项目，且已获得相关授权。
- 插件作者：电排骨，QQ：2639367181。